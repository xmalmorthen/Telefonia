/*
   ####################################################################################
   #                                                                                  #
   #             Arfcncalc - GSM Arfcn frequency calculation tool V1.0.0              #
   #                                  Lookup tables                                   #
   #                                                                                  #
   #    Copyright (C) 2008 Philipp Fabian Benedikt Maier (aka. Dexter)                #
   #                                                                                  #
   #    This program is free software; you can redistribute it and/or modify          #
   #    it under the terms of the GNU General Public License as published by          #
   #    the Free Software Foundation; either version 2 of the License, or             #
   #    (at your option) any later version.                                           #
   #                                                                                  #
   #    This program is distributed in the hope that it will be useful,               #
   #    but WITHOUT ANY WARRANTY; without even the implied warranty of                #
   #    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the                 #
   #    GNU General Public License for more details.                                  #
   #                                                                                  #
   #    You should have received a copy of the GNU General Public License             #
   #    along with this program; if not, write to the Free Software                   #
   #    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA    #
   #                                                                                  #
   #################################################################################### */


/* ## HEADER ########################################################################## */
#ifndef LOOKUP_H
#define LOOKUP_H

/* Lookup functions: */

/* Transform a given band to to a human readable band description string */
int band2string(int band, char *string);

/* Find out the country for a given band */
int band2country(int band, char *string);

/* Get a more detailed information about the band */
int arfn2bandetail(int arfcn, int band, char *string);

/* Try to find out the band for a given arfcn */
int arfcn2band(int arfcn);

/* Find out the offset for a given arfcn */
int arfcn2offset(int arfcn);

/* Find out difference between rx and tx for a given arfcn */
int arfcn2rxtxdiff(int arfcn, int band);

/* Find out start frequency */
int arfcn2startfreq(int arfcn, int band);

/* Try to find out to which provider the frequency is allocated */
int frequency2provider(int country, int frequency, char *provider);

#if 0
/* Reverse-lookup functions: */

/* Find the offset for a given uplink frequency */
int fuplink2offset(int frequency);

/* Find the offset for a given downlink frequency */
int fdownlink2offset(int frequency);

/* Find the startfrequency for a given uplink frequency */
int fuplink2startfreq(int frequency);

/* Find the startfrequency for a given downlink frequency */
int fdownlink2startfreq(int frequency);

/* Find the difference between rx and tx for a given uplink frequency */
int fuplink2rxtxdiff(int frequency);

/* Find the difference between rx and tx for a given downlink frequency */
int fdownlink2rxtxdiff(int frequency);

#endif

#endif /*LOOKUP_H*/
/* #################################################################################### */
