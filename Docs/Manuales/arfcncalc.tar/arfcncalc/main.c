/*
   ####################################################################################
   #                                                                                  #
   #             Arfcncalc - GSM Arfcn frequency calculation tool V1.0.0              #
   #                                  Main program                                    #
   #                                                                                  #
   #    Copyright (C) 2008 Philipp Fabian Benedikt Maier (aka. Dexter)                #
   #                                                                                  #
   #    This program is free software; you can redistribute it and/or modify          #
   #    it under the terms of the GNU General Public License as published by          #
   #    the Free Software Foundation; either version 2 of the License, or             #
   #    (at your option) any later version.                                           #
   #                                                                                  #
   #    This program is distributed in the hope that it will be useful,               #
   #    but WITHOUT ANY WARRANTY; without even the implied warranty of                #
   #    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the                 #
   #    GNU General Public License for more details.                                  #
   #                                                                                  #
   #    You should have received a copy of the GNU General Public License             #
   #    along with this program; if not, write to the Free Software                   #
   #    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA    #
   #                                                                                  #
   #################################################################################### */


/* ## HEADER ########################################################################## */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <getopt.h>
#include <libgen.h>

#include "band.h"
#include "arfcn.h"
#include "lookup.h"
#include "calc.h"
#include "country.h"

char programName[255];

#define UPLINK 'U'
#define DOWNLINK 'D'
/* #################################################################################### */


/* #################################################################################### */

/* Generate a frequency allocation table */
void generateFrequencyTable(int startArfcn, int endArfcn, int band)
{
	int arfcn;
	int fuplink; 
	int fdownlink;
	char banddetail[255];

	arfn2bandetail(startArfcn, band, banddetail);
	
	printf(" * Frequency table for the GSM%i %s Band:\r\n",band,banddetail);
	for(arfcn=startArfcn;arfcn<=endArfcn;arfcn++)
	{
		calcFreqnencyFromArfcn(arfcn,band,&fuplink,&fdownlink);
		printf("Arfcn: %i   Uplink: %i000Hz   Downlink: %i000Hz\r\n",arfcn,fuplink,fdownlink);
	}
	printf("\r\n");
	return;
}

/* Generate a frequency allocation table for all known bands */
void generateCompleteFrequencyTable(void)
{
	generateFrequencyTable(ARFCN_GSM450_START,ARFCN_GSM450_END,BAND_GSM450);
	generateFrequencyTable(ARFCN_GSM480_START,ARFCN_GSM480_END,BAND_GSM480);
	generateFrequencyTable(ARFCN_GSM850_START,ARFCN_GSM850_END,BAND_GSM850);
	generateFrequencyTable(ARFCN_GSM900_START,ARFCN_GSM900_END,BAND_GSM900);
	generateFrequencyTable(ARFCN_REGSM900_START,ARFCN_REGSM900_END,BAND_GSM900);
	generateFrequencyTable(ARFCN_GSM1800_START,ARFCN_GSM1800_END,BAND_GSM1800);
	generateFrequencyTable(ARFCN_GSM1900_START,ARFCN_GSM1900_END,BAND_GSM1900);
}

/* Try to find an arfcn for a given frequency in a given band */
int testFrequencyInBand(int frequency, int startArfcn, int endArfcn, int band, int upOrDownlink)
{
	int arfcn;
	int fuplink; 
	int fdownlink;

	for(arfcn=startArfcn;arfcn<=endArfcn;arfcn++)
	{
		calcFreqnencyFromArfcn(arfcn,band,&fuplink,&fdownlink);

		if(upOrDownlink == UPLINK)
		{
			if((frequency < fuplink + 100)&&(frequency > fuplink - 100))
				return arfcn;
		}
		else if(upOrDownlink == DOWNLINK)
		{
			if((frequency < fdownlink + 100)&&(frequency > fdownlink - 100))
				return arfcn;
		}
		else if(upOrDownlink == 0)
		{
			if((frequency < fdownlink + 100)&&(frequency > fdownlink - 100))
				return arfcn;
			if((frequency < fuplink + 100)&&(frequency > fuplink - 100))
				return arfcn;
		}
	}

	return -1;
}

/* Try to find an arfcn for a given frequency in all bands */
int testFrequencyInCompleteBand(int frequency, int preferedBand, int upOrDownlink)
{
	int arfcn;

	/* When the band is not speciefied, just go through all frequencys and find the first best suitable arfcn */
	if(preferedBand == 0)
	{
		arfcn = testFrequencyInBand(frequency, ARFCN_GSM450_START,ARFCN_GSM450_END,BAND_GSM450,upOrDownlink);
		if(arfcn != -1)
			return arfcn;

		arfcn = testFrequencyInBand(frequency, ARFCN_GSM480_START,ARFCN_GSM480_END,BAND_GSM480,upOrDownlink);
		if(arfcn != -1)
			return arfcn;

		arfcn = testFrequencyInBand(frequency, ARFCN_GSM850_START,ARFCN_GSM850_END,BAND_GSM850,upOrDownlink);
		if(arfcn != -1)
			return arfcn;

		arfcn = testFrequencyInBand(frequency, ARFCN_GSM900_START,ARFCN_GSM900_END,BAND_GSM900,upOrDownlink);
		if(arfcn != -1)
			return arfcn;

		arfcn = testFrequencyInBand(frequency, ARFCN_REGSM900_START,ARFCN_REGSM900_END,BAND_GSM900,upOrDownlink);
		if(arfcn != -1)
			return arfcn;

		arfcn = testFrequencyInBand(frequency, ARFCN_GSM1800_START,ARFCN_GSM1800_END,BAND_GSM1800,upOrDownlink);
		if(arfcn != -1)
			return arfcn;

		arfcn = testFrequencyInBand(frequency, ARFCN_GSM1900_START,ARFCN_GSM1900_END,BAND_GSM1900,upOrDownlink);
		if(arfcn != -1)
			return arfcn;

		return -1;
	}
	else
	{
		if(preferedBand == BAND_GSM450)
			return testFrequencyInBand(frequency, ARFCN_GSM450_START,ARFCN_GSM450_END,BAND_GSM450,upOrDownlink);

		if(preferedBand == BAND_GSM480)
			return testFrequencyInBand(frequency, ARFCN_GSM480_START,ARFCN_GSM480_END,BAND_GSM480,upOrDownlink);

		if(preferedBand == BAND_GSM850)
			return testFrequencyInBand(frequency, ARFCN_GSM850_START,ARFCN_GSM850_END,BAND_GSM850,upOrDownlink);

		if(preferedBand == BAND_GSM900)
		{
			arfcn = testFrequencyInBand(frequency, ARFCN_GSM900_START,ARFCN_GSM900_END,BAND_GSM900,upOrDownlink);
			if(arfcn != -1)
				return arfcn;

			arfcn = testFrequencyInBand(frequency, ARFCN_REGSM900_START,ARFCN_REGSM900_END,BAND_GSM900,upOrDownlink);
			if(arfcn != -1)
				return arfcn;

			return -1;
		}

		if(preferedBand == BAND_GSM1800)
			return testFrequencyInBand(frequency, ARFCN_GSM1800_START,ARFCN_GSM1800_END,BAND_GSM1800,upOrDownlink);

		if(preferedBand == BAND_GSM1900)
			return testFrequencyInBand(frequency, ARFCN_GSM1900_START,ARFCN_GSM1900_END,BAND_GSM1900,upOrDownlink);

	}

	return -1;
}

/* Print copyright/programname headline */
void printHeadline(void)
{
	printf("_______________________________________________________________________________\n\r");
	printf("ArfcnCalc - GSM frequency calculation tool V.1.0\n\r");
	printf("Copyright(c) 2010 Philipp Fabian Benedikt Maier\n\r");
	printf("\n\r");
	printf("CAUTION: This is a very early version of this program. It might still contain\r\n");
	printf("         some bugs that might cause wrong calculation results. If you find a\r\n");
	printf("         bug, please email to: philipp.maier@runningserver.com - Thanks!\r\n");
	printf("\n\r");
	return;
}

/* Print online help */
void printHelp(void)
{
	printHeadline();

	printf("This is a tool for calculating the resulting frequency from a given ARFCN\r\n");
	printf("and can be used easyly in shellscripts for doing arfcn calculations\r\n");
	printf("\r\n");
	printf("The following options are available\r\n");
	printf(" -h or -? ........ Print this screen.\r\n");
	printf(" -v .............. Verbose output.\r\n");
	printf(" -u .............. Calculate uplink frequency  / Treat frequency as uplink\r\n");
	printf(" -d .............. Calculate downlink frequency / Treat frequency as downlik\r\n");
	printf(" -b .............. Specify band (optional, needed with GSM1900/1800).\r\n");
	printf(" -p .............. Generate a bandplan with all known arfcns.\r\n");
	printf(" -f .............. Find an Arfcn for a given frequency\r\n");
	printf("\r\n");
	printf("The following bands can be handled (option -b):\r\n");
	printf(" 450 ............. GSM450\r\n");
	printf(" 480 ............. GSM480\r\n");
	printf(" 850 ............. GSM850\r\n");
	printf(" 900 ............. GSM900 (P-GSM, E-GSM and R-GSM)\r\n");
	printf(" 1800 ............ GSM1800 \\__Caution:\r\n");
	printf(" 1900 ............ GSM1900 /  Conflicting ARFCN-Numbers!\r\n");
	printf("\r\n");
	printf("Usage:\r\n");
	printf(" %s -a arfcen [-udv -b band] ..... Calculate the frequency for an arfcn\r\n",programName);
	printf(" %s -f frequency [-udv -b band] .. Calculate arfcn for a frequency\r\n",programName);
	printf(" %s -p ........................... Generate bandplan\r\n",programName);
	printf("\r\n");
	printf("Examples:\r\n");
	printf(" %s -a 512 -b 1900 -d ... Calc downlink frequency (GSM1900) of Arfcn 512\r\n",programName);
	printf(" %s -a 123 -v ........... Get verbose information about Arfcn 123\r\n",programName);
	printf(" %s -f 959600000 -d ..... Get an arfcn for the dnlink frequency 959.6Mhz\r\n",programName);
	printf("\r\n");
	exit(0);
}

/* Display verbose arfcn info */
void displayArfcnInfo(int arfcn, int band)
{
	int fuplink; 
	int fdownlink;
	char bandstring[255];
	char banddetailstring[255];
	char countrystring[255];
	char providerstring[255];

	calcFreqnencyFromArfcn(arfcn,band,&fuplink,&fdownlink);

	/* Display ARFCN */
	printf(" * Arfn: %i\r\n",arfcn);

	/* Display up and downlink frequency */
	printf(" * Downlink frequency is: %i000 Hz\r\n",fdownlink);
	printf(" * Uplink frequency is: %i000 Hz\r\n",fuplink);
	printf(" * Distance: %i000 Hz\r\n",arfcn2rxtxdiff(arfcn,band));
	printf(" * Offset: %i\r\n",arfcn2offset(arfcn));

	if(frequency2provider(COUNTRY_GERMANY, fdownlink, providerstring) == 0)
		printf(" * Licensed to %s in Germany\r\n",providerstring);
	if(frequency2provider(COUNTRY_AUSTRIA, fdownlink, providerstring) == 0)
		printf(" * Licensed to %s in Austria\r\n",providerstring);
	if(frequency2provider(COUNTRY_SWISS, fdownlink, providerstring) == 0)
		printf(" * Licensed to %s in Swissland\r\n",providerstring);
	if(frequency2provider(COUNTRY_ENGLAND, fdownlink, providerstring) == 0)
		printf(" * Licensed to %s in England\r\n",providerstring);

	/* Display in which band the arfcn is located */
	if(band2string(band, bandstring) != -1)
	{
		printf(" * Band: %s",bandstring);

		if(arfn2bandetail(arfcn, band, banddetailstring) == 0)
			printf(" %s",banddetailstring);
		printf("\r\n");
	}

	/* Try to find out the country where the band is operated in */
	if(band2country(band,countrystring) != -1)
		printf(" * Country(s): %s\r\n",countrystring);

	printf("\r\n");

	return;
}

/* Display uplink frequency in short form */
void displayUplink(int arfcn, int band)
{
	int fuplink; 
	int fdownlink;
	calcFreqnencyFromArfcn(arfcn,band,&fuplink,&fdownlink);
	printf("%i000\r\n",fuplink);
}

/* Display downlink frequency in short form */
void displayDownlink(int arfcn, int band)
{
	int fuplink; 
	int fdownlink;
	calcFreqnencyFromArfcn(arfcn,band,&fuplink,&fdownlink);
	printf("%i000\r\n",fdownlink);
}

/* ## MAIN PROGRAM #################################################################### */
int main(int argc, char *argv[])
{
	/* Calculation results */
	int arfcn;
	int band;
	int frequency;

	/* Global var with program name */
	strcpy(programName,basename(argv[0]));

	/* No arguments will trigger help screen */
	if(argc == 1)
		printHelp();

	/* Getopt stuff */
	int getoptOption;
	int getoptArfcnSet = 0;
     	int getoptArfcn;
	int getoptDownlinkSet = 0;
	int getoptUplinkSet = 0;
	int getoptVerboseSet = 0;
	int getoptBandSet = 0;
	int getoptBand = 0;
	int getoptPlanSet = 0;
	int getoptFrequencySet = 0;
	int getoptFrequency = 0;

	while ((getoptOption = getopt (argc, argv, "ph?a:duvb:f:")) != -1)
		switch (getoptOption)
		{
			case 'h':printHelp();
			case '?':printHelp();
			case 'p':
				getoptPlanSet = 1;
			break;
			case 'a':
				getoptArfcn = atoi(optarg);
				getoptArfcnSet = 1;
			break;
			case 'f':
				getoptFrequency = atoi(optarg);
				getoptFrequencySet = 1;
			break;
			case 'd':
				getoptDownlinkSet = 1;
			break;
			case 'u':
				getoptUplinkSet = 1;
			break;
			case 'v':
				getoptVerboseSet = 1;
			break;
			case 'b':
				getoptBand = atoi(optarg);
				getoptBandSet = 1;
			break;

		}

	/* Generate a complete bandplan */
	if(getoptPlanSet)
	{
		printHeadline();
		generateCompleteFrequencyTable();
		exit(0);
	}

	/* In verbose mode, display copyright headline */
	if(getoptVerboseSet)
		printHeadline();
	
	/* When an arfcn is given, determine the band the arfcn belongs to: */
	if(getoptArfcnSet)
	{
		arfcn = getoptArfcn;

		/* Check whether the arfcn belongs to any band. If not it must be invalid */
		if(arfcn2band(arfcn) == -1)
		{
			printf("%s: %i: Invalid arfcn\r\n",programName,arfcn);
			exit(1);
		}

		if(getoptBandSet)
			band = getoptBand;		/* Band is supplyed as argument */
		else
		{
			band = arfcn2band(getoptArfcn);	/* Try to derive the band from the given arfcn */

			/* Display warning when ARFCN is in GSM1800 or GSM1900 */
			if((arfcn2band(getoptArfcn) == BAND_GSM1800)||(arfcn2band(getoptArfcn) == BAND_GSM1900))
				printf(" * Warning: GSM1800 and GSM1900 share comman ARFCNs, you\r\n"
				       "            should specify a band.\r\n");
		}

		/* Make sure that band and arfcn fit together */
		if(getoptBandSet)
			if(arfcn2band(getoptArfcn) != getoptBand)
				if(getoptBand != BAND_GSM1900)
				{
					printf("%s: GSM%i: Band does not fit to arfcn\r\n",programName,getoptBand);
					exit(1);
				}


		/* Display verbose information */
		if(getoptVerboseSet)
		{
			displayArfcnInfo(arfcn,band);
			exit(0);
		}
		/* Display short finformation (more suitable for shellscripts) */
		else
		{
			/* Downlink frequency */
			if(getoptDownlinkSet)
			{
				displayDownlink(arfcn, band);
				exit(0);
			}
			/* Uplink frequency */
			else if(getoptUplinkSet)
			{
				displayUplink(arfcn, band);
				exit(0);
			}
			/* Nothing */
			else
			{
				printf("%s: No output method selected\r\n",programName);
				exit(1);
			}
		}
	}
	else if(getoptFrequencySet)
	{
		if(getoptBandSet)
			band = getoptBand;
		else
			band = BAND_ALLOTHERS;

		frequency = getoptFrequency / 1000;

		if(getoptDownlinkSet)
			arfcn = testFrequencyInCompleteBand(frequency,getoptBand,DOWNLINK);
		else if(getoptUplinkSet)
			arfcn = testFrequencyInCompleteBand(frequency,getoptBand,UPLINK);
		else
			arfcn = testFrequencyInCompleteBand(frequency,getoptBand,0);

		if(arfcn == -1)
		{
			printf("%s: %i: Frequency is not part of an GSM-Band\r\n",programName,frequency);
			exit(1);
		}

		/* Try to find the band if it is not given */;
		if(!(getoptBandSet))
			band = arfcn2band(arfcn);

		/* Display verbose information */
		if(getoptVerboseSet)
		{
			displayArfcnInfo(arfcn,band);
			exit(0);
		}
		/* Display short finformation (more suitable for shellscripts) */
		else
		{
			/* Arfcn */
			printf("%i\n",arfcn);
			exit(0);
		}
	}
	else
	{
		printf("%s: You must spefify an ARFCN\r\n",programName);
		exit(1);
	}


	return 0;
}
/* #################################################################################### */


