/*
   ####################################################################################
   #                                                                                  #
   #             Arfcncalc - GSM Arfcn frequency calculation tool V1.0.0              #
   #                                   GSM-Arfns                                      #
   #                                                                                  #
   #    Copyright (C) 2008 Philipp Fabian Benedikt Maier (aka. Dexter)                #
   #                                                                                  #
   #    This program is free software; you can redistribute it and/or modify          #
   #    it under the terms of the GNU General Public License as published by          #
   #    the Free Software Foundation; either version 2 of the License, or             #
   #    (at your option) any later version.                                           #
   #                                                                                  #
   #    This program is distributed in the hope that it will be useful,               #
   #    but WITHOUT ANY WARRANTY; without even the implied warranty of                #
   #    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the                 #
   #    GNU General Public License for more details.                                  #
   #                                                                                  #
   #    You should have received a copy of the GNU General Public License             #
   #    along with this program; if not, write to the Free Software                   #
   #    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA    #
   #                                                                                  #
   #################################################################################### */


/* ## HEADER ########################################################################## */
#ifndef ARFCN_H
#define ARFCN_H

#define ARFCN_GSM450_START	259
#define ARFCN_GSM450_END	293
#define ARFCN_GSM480_START	306
#define ARFCN_GSM480_END	340
#define ARFCN_GSM850_START	128
#define ARFCN_GSM850_END	251
#define ARFCN_GSM900_START	0
#define ARFCN_GSM900_END	124
#define ARFCN_REGSM900_START	955
#define ARFCN_REGSM900_END	1023
#define ARFCN_GSM1800_START	512
#define ARFCN_GSM1800_END	885
#define ARFCN_GSM1900_START	512
#define ARFCN_GSM1900_END	810

#endif /*ARFCN_H*/
/* #################################################################################### */
