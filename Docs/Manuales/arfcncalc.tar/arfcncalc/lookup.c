/*
   ####################################################################################
   #                                                                                  #
   #             Arfcncalc - GSM Arfcn frequency calculation tool V1.0.0              #
   #                                  Lookup tables                                   #
   #                                                                                  #
   #    Copyright (C) 2008 Philipp Fabian Benedikt Maier (aka. Dexter)                #
   #                                                                                  #
   #    This program is free software; you can redistribute it and/or modify          #
   #    it under the terms of the GNU General Public License as published by          #
   #    the Free Software Foundation; either version 2 of the License, or             #
   #    (at your option) any later version.                                           #
   #                                                                                  #
   #    This program is distributed in the hope that it will be useful,               #
   #    but WITHOUT ANY WARRANTY; without even the implied warranty of                #
   #    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the                 #
   #    GNU General Public License for more details.                                  #
   #                                                                                  #
   #    You should have received a copy of the GNU General Public License             #
   #    along with this program; if not, write to the Free Software                   #
   #    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA    #
   #                                                                                  #
   #################################################################################### */


/* ## HEADER ########################################################################## */
#include <stdio.h>
#include <string.h>
#include "band.h"
#include "arfcn.h"
#include "lookup.h"
#include "country.h"
#include "provider.h"
/* #################################################################################### */


/* ## LOOKUP TABLES ################################################################### */

/* Transform a given band to to a human readable band description string */
int band2string(int band, char *string)
{
	string[0] = 0;

	switch(band)
	{
		case BAND_GSM450: 
			strcpy(string,"GSM450");
		break;
		case BAND_GSM480: 
			strcpy(string,"GSM480");
		break;
		case BAND_GSM850: 
			strcpy(string,"GSM850");
		break;
		case BAND_GSM900: 
			strcpy(string,"GSM900");
		break;
		case BAND_GSM1800: 
			strcpy(string,"GSM1800");
		break;
		case BAND_GSM1900: 
			strcpy(string,"GSM1900");
		break;
		default:
			return -1;		
	}

	return 0;
}

/* Get a more detailed information about the band */
int arfn2bandetail(int arfcn, int band, char *string)
{
	string[0] = 0;

	if((arfcn >= ARFCN_GSM450_START)&&(arfcn <= ARFCN_GSM450_END))	/* GSM 450 */
		return -1;		/* No details available */
	else if((arfcn >= ARFCN_GSM480_START)&&(arfcn <= ARFCN_GSM480_END))	/* GSM 480 */
		return -1;		/* No details available */
	else if((arfcn >= ARFCN_GSM850_START)&&(arfcn <= ARFCN_GSM850_END))	/* GSM 850 */
		return -1;		/* No details available */
	else if(arfcn == ARFCN_GSM900_START)			/* GSM 900, E-GSM or R-GSM */
	{
		strcpy(string,"(E-GSM or R-GSM)");
		return 0;
	}
	else if((arfcn >= ARFCN_GSM900_START+1)&&(arfcn <= ARFCN_GSM900_END))	/* GSM 900 E-GSM, R-GSM or P-GSM */
	{
		strcpy(string,"(P-GSM, E-GSM or R-GSM)");
		return 0;
	}
	else if((arfcn >= ARFCN_REGSM900_START)&&(arfcn <= ARFCN_REGSM900_END)) /* R-GSM 900 */
	{
		strcpy(string,"(E-GSM or R-GSM)");
		return 0;
	}
	else if((arfcn >= ARFCN_GSM1900_START)&&(arfcn <= ARFCN_GSM1900_END)&&(band == BAND_GSM1900))	/* PCS 1900 (GSM 1900) */
	{
		strcpy(string,"(PCS 1900)");
		return 0;
	}
	else if((arfcn >= ARFCN_GSM1800_START)&&(arfcn <= ARFCN_GSM1800_END))	/* DCS 1800 (GSM 1800) */
	{
		strcpy(string,"(DCS 1800)");
		return 0;
	}
	else
		return -1;
}

/* Find out the country for a given band */
int band2country(int band, char *string)
{
	string[0] = 0;

	switch(band)
	{
		case BAND_GSM450: 
			strcpy(string,"NORDIC, BENELUX, ALPINE, RUSSIA, EASTERN EUROPE, TANZANIA");
		break;
		case BAND_GSM480: 
			strcpy(string,"NOT IN USE ?");
		break;
		case BAND_GSM850: 
			strcpy(string,"USA, CANADA, BRAZIL, GUATEMALA, EL SALVADOR");
		break;
		case BAND_GSM900: 
			strcpy(string,"EUROPE, BRAZIL, GUATEMALA, EL SALVADOR");
		break;
		case BAND_GSM1800: 
			strcpy(string,"EUROPE, COSTA RICA, BRAZIL, HONG-KONG");
		break;
		case BAND_GSM1900: 
			strcpy(string,"USA, CANADA, GUATEMALA, EL SALVADOR");
		break;
		default:
			return -1;		
	}

	return 0;
}

/* Try to find out the band for a given arfcn */
int arfcn2band(int arfcn)
{
	if((arfcn >= ARFCN_GSM450_START)&&(arfcn <= ARFCN_GSM450_END))	/* GSM 450 */
		return BAND_GSM450;
	else if((arfcn >= ARFCN_GSM480_START)&&(arfcn <= ARFCN_GSM480_END))	/* GSM 480 */
		return BAND_GSM480;
	else if((arfcn >= ARFCN_GSM850_START)&&(arfcn <= ARFCN_GSM850_END))	/* GSM 850 */
		return BAND_GSM850;
	else if((arfcn >= ARFCN_GSM900_START)&&(arfcn <= ARFCN_GSM900_END))	/* E-GSM, R-GSM or P-GSM */
		return BAND_GSM900;
	else if((arfcn >= ARFCN_REGSM900_START)&&(arfcn <= ARFCN_REGSM900_END)) /* R-GSM 900 */
		return BAND_GSM900;
	else if((arfcn >= ARFCN_GSM1800_START)&&(arfcn <= ARFCN_GSM1800_END))	/* DCS 1800 (GSM 1800) */
		return BAND_GSM1800;
	else if((arfcn >= ARFCN_GSM1900_START)&&(arfcn <= ARFCN_GSM1900_END))	/* DCS 1800 (GSM 1800) and PCS 1900 (GSM 1900) */
		return BAND_GSM1900;
	else
		return -1;
}

/* Find out the offset for a given arfcn */
int arfcn2offset(int arfcn)
{
	if((arfcn >= ARFCN_GSM450_START)&&(arfcn <= ARFCN_GSM450_END))	/* GSM 450 */
		return 259;
	else if((arfcn >= ARFCN_GSM480_START)&&(arfcn <= ARFCN_GSM480_END))	/* GSM 480 */
		return 306;
	else if((arfcn >= ARFCN_GSM850_START)&&(arfcn <= ARFCN_GSM850_END))	/* GSM 850 */
		return 128;
	else if((arfcn >= ARFCN_GSM900_START)&&(arfcn <= ARFCN_GSM900_END))	/* E-GSM, R-GSM or P-GSM */
		return 0;
	else if((arfcn >= ARFCN_REGSM900_START)&&(arfcn <= ARFCN_REGSM900_END)) /* R-GSM 900 */
		return 1024;
	else if((arfcn >= ARFCN_GSM1800_START)&&(arfcn <= ARFCN_GSM1800_END))	/* DCS 1800 (GSM 1800) and PCS 1900 (GSM 1900) */
		return 512;
	else
		return -1;
}

/* Find out difference between rx and tx for a given arfcn */
int arfcn2rxtxdiff(int arfcn, int band)
{
	if((arfcn >= ARFCN_GSM450_START)&&(arfcn <= ARFCN_GSM450_END))	/* GSM 450 */
		return 10000;
	else if((arfcn >= ARFCN_GSM480_START)&&(arfcn <= ARFCN_GSM480_END))	/* GSM 480 */
		return 10000;
	else if((arfcn >= ARFCN_GSM850_START)&&(arfcn <= ARFCN_GSM850_END))	/* GSM 850 */
		return 45000;
	else if((arfcn >= ARFCN_GSM900_START)&&(arfcn <= ARFCN_GSM900_END))	/* E-GSM, R-GSM or P-GSM */
		return 45000;
	else if((arfcn >= ARFCN_REGSM900_START)&&(arfcn <= ARFCN_REGSM900_END)) /* R-GSM 900 */
		return 45000;
	else if((arfcn >= ARFCN_GSM1900_START)&&(arfcn <= ARFCN_GSM1900_END)&&(band == BAND_GSM1900))	/* PCS 1900 (GSM 1900) */
		return 80000;
	else if((arfcn >= ARFCN_GSM1800_START)&&(arfcn <= ARFCN_GSM1800_END))	/* DCS 1800 (GSM 1800) */
		return 95000;
	else
		return -1;
}



/* Find out start frequency */
int arfcn2startfreq(int arfcn, int band)
{
	if((arfcn >= ARFCN_GSM450_START)&&(arfcn <= ARFCN_GSM450_END))	/* GSM 450 */
		return 450600;
	else if((arfcn >= ARFCN_GSM480_START)&&(arfcn <= ARFCN_GSM480_END))	/* GSM 480 */
		return 479000;
	else if((arfcn >= ARFCN_GSM850_START)&&(arfcn <= ARFCN_GSM850_END))	/* GSM 850 */
		return 824200;
	else if((arfcn >= ARFCN_GSM900_START)&&(arfcn <= ARFCN_GSM900_END))	/* E-GSM, R-GSM or P-GSM */
		return 890000;
	else if((arfcn >= ARFCN_REGSM900_START)&&(arfcn <= ARFCN_REGSM900_END)) /* R-GSM 900 */
		return 890000;
	else if((arfcn >= ARFCN_GSM1900_START)&&(arfcn <= 810)&&(band == BAND_GSM1900))	/* PCS 1900 (GSM 1900) */
		return 1850200;
	else if((arfcn >= ARFCN_GSM1800_START)&&(arfcn <= ARFCN_GSM1800_END))	/* DCS 1800 (GSM 1800) */
		return 1710200;
	else	
		return -1;
}

/* Try to find out to which provider the frequency is allocated */
int frequency2provider(int country, int frequency, char *provider)
{
	if(country == COUNTRY_GERMANY)
	{	
		/* GSM900 */
		if((frequency >= 876200)&&(frequency <= 880000))
		{
			strcpy(provider,PROVIDER_GERMANY_DEUTSCHEBAHN);
			return 0;
		}
		else if((frequency >= 880100)&&(frequency <= 885100))
		{
			strcpy(provider,PROVIDER_GERMANY_EPLUS);
			return 0;
		}
		else if((frequency >= 885100)&&(frequency <= 890100))
		{
			strcpy(provider,PROVIDER_GERMANY_O2);
			return 0;
		}
		else if((frequency >= 890200)&&(frequency <= 892400))
		{
			strcpy(provider,PROVIDER_GERMANY_VODAFONE);
			return 0;
		}
		else if((frequency >= 892600)&&(frequency <= 899800))
		{
			strcpy(provider,PROVIDER_GERMANY_TMOBILE);
			return 0;
		}
		else if((frequency >= 900000)&&(frequency <= 906000))
		{
			strcpy(provider,PROVIDER_GERMANY_VODAFONE);
			return 0;
		}
		else if((frequency >= 906200)&&(frequency <= 910400))
		{
			strcpy(provider,PROVIDER_GERMANY_TMOBILE);
			return 0;
		}
		else if((frequency >= 910600)&&(frequency <= 914200))
		{
			strcpy(provider,PROVIDER_GERMANY_VODAFONE);
			return 0;
		}
		else if((frequency >= 921200)&&(frequency <= 925000))
		{
			strcpy(provider,PROVIDER_GERMANY_DEUTSCHEBAHN);
			return 0;
		}
		else if((frequency >= 925100)&&(frequency <= 930100))
		{
			strcpy(provider,PROVIDER_GERMANY_EPLUS);
			return 0;
		}
		else if((frequency >= 930100)&&(frequency <= 935100))
		{
			strcpy(provider,PROVIDER_GERMANY_O2);
			return 0;
		}
		else if((frequency >= 935200)&&(frequency <= 937400))
		{
			strcpy(provider,PROVIDER_GERMANY_VODAFONE);
			return 0;
		}
  	  	else if((frequency >= 937600)&&(frequency <= 944800))
		{
			strcpy(provider,PROVIDER_GERMANY_TMOBILE);
			return 0;
		}
  	  	else if((frequency >= 945000)&&(frequency <= 951000))
		{
			strcpy(provider,PROVIDER_GERMANY_VODAFONE);
			return 0;
		}
  	    	else if((frequency >= 951200)&&(frequency <= 955400))
		{
			strcpy(provider,PROVIDER_GERMANY_TMOBILE);
			return 0;
		}
  	    	else if((frequency >= 955600)&&(frequency <= 959200))
		{
			strcpy(provider,PROVIDER_GERMANY_VODAFONE);
			return 0;
		}
  	    	else if((frequency >= 959400)&&(frequency <= 959800))
		{
			strcpy(provider,PROVIDER_GERMANY_TMOBILE);
			return 0;
		}
		/* GSM1800 */
  	    	else if((frequency >= 1725200)&&(frequency <= 1730000))
		{
			strcpy(provider,PROVIDER_GERMANY_TMOBILE);
			return 0;
		}
  	    	else if((frequency >= 1730200)&&(frequency <= 1752400))
		{
			strcpy(provider,PROVIDER_GERMANY_O2);
			return 0;
		}
  	    	else if((frequency >= 1752800)&&(frequency <= 1758000))
		{
			strcpy(provider,PROVIDER_GERMANY_VODAFONE);
			return 0;
		}
  	    	else if((frequency >= 1758200)&&(frequency <= 1780400))
		{
			strcpy(provider,PROVIDER_GERMANY_EPLUS);
			return 0;
		}
  	    	else if((frequency >= 1820200)&&(frequency <= 1825000))
		{
			strcpy(provider,PROVIDER_GERMANY_TMOBILE);
			return 0;
		}
  	    	else if((frequency >= 1825000)&&(frequency <= 1847400))
		{
			strcpy(provider,PROVIDER_GERMANY_O2);
			return 0;
		}
  	    	else if((frequency >= 1847800)&&(frequency <= 1853000))
		{
			strcpy(provider,PROVIDER_GERMANY_VODAFONE);
			return 0;
		}
  	    	else if((frequency >= 1853200)&&(frequency <= 1875400))
		{
			strcpy(provider,PROVIDER_GERMANY_EPLUS);
			return 0;
		}
	}
	else if(country == COUNTRY_AUSTRIA)
	{	
		/* GSM900 */
		if((frequency >= 880200)&&(frequency <= 883200))
		{
			strcpy(provider, PROVIDER_AUSTRIA_ONE);
			return 0;
		}
		else if((frequency >= 883600)&&(frequency <= 889800))
		{
			strcpy(provider, PROVIDER_AUSTRIA_MOBILKOM);
			return 0;
		}
		else if((frequency >= 893000)&&(frequency <= 897800))
		{
			strcpy(provider, PROVIDER_AUSTRIA_TMOBILE);
			return 0;
		}
		else if((frequency >= 898200)&&(frequency <= 905800))
		{
			strcpy(provider, PROVIDER_AUSTRIA_MOBILKOM);
			return 0;
		}
  	  	else if((frequency >= 906200)&&(frequency <= 913800))
		{
			strcpy(provider, PROVIDER_AUSTRIA_TMOBILE);
			return 0;
		}
  	  	else if((frequency >= 925200)&&(frequency <= 928200))
		{
			strcpy(provider, PROVIDER_AUSTRIA_ONE);
			return 0;
		}
  	  	else if((frequency >= 928600)&&(frequency <= 934800))
		{
			strcpy(provider, PROVIDER_AUSTRIA_MOBILKOM);
			return 0;
		}
  	  	else if((frequency >= 938000)&&(frequency <= 942800))
		{
			strcpy(provider, PROVIDER_AUSTRIA_TMOBILE);
			return 0;
		}
  	  	else if((frequency >= 943200)&&(frequency <= 950800))
		{
			strcpy(provider, PROVIDER_AUSTRIA_MOBILKOM);
			return 0;
		}
  	  	else if((frequency >= 951200)&&(frequency <= 958800))
		{
			strcpy(provider, PROVIDER_AUSTRIA_TMOBILE);
			return 0;
		}
		/* GSM1800 */
  	    	else if((frequency >= 1710200)&&(frequency <= 1712000))
		{
			strcpy(provider, PROVIDER_AUSTRIA_TMOBILE);
			return 0;
		}
  	    	else if((frequency >= 1712400)&&(frequency <= 1722400))
		{
			strcpy(provider, PROVIDER_AUSTRIA_MOBILKOM);
			return 0;
		}
    	    	else if((frequency >= 1722800)&&(frequency <= 1731200))
		{
			strcpy(provider, PROVIDER_AUSTRIA_TMOBILE);
			return 0;
		}
      	    	else if((frequency >= 1731600)&&(frequency <= 1733800))
		{
			strcpy(provider, PROVIDER_AUSTRIA_MOBILKOM);
			return 0;
		}	  	  	
      	    	else if((frequency >= 1734200)&&(frequency <= 1739600))
		{
			strcpy(provider, PROVIDER_AUSTRIA_ONE);
			return 0;
		}
      	    	else if((frequency >= 1740000)&&(frequency <= 1741000))
		{
			strcpy(provider, PROVIDER_AUSTRIA_TMOBILE);
			return 0;
		}	  	  	
        	else if((frequency >= 1741400)&&(frequency <= 1742400))
		{
			strcpy(provider, PROVIDER_AUSTRIA_MOBILKOM);
			return 0;
		}	
        	else if((frequency >= 1742800)&&(frequency <= 1743800))
		{
			strcpy(provider, PROVIDER_AUSTRIA_TMOBILE);
			return 0;
		}	  	 	 	  	 	
        	else if((frequency >= 1744200)&&(frequency <= 1747600))
		{
			strcpy(provider, PROVIDER_AUSTRIA_TMOBILE);
			return 0;
		}	
        	else if((frequency >= 1748000)&&(frequency <= 1750200))
		{
			strcpy(provider, PROVIDER_AUSTRIA_TMOBILE);
			return 0;
		}  
        	else if((frequency >= 1750600)&&(frequency <= 1755000))
		{
			strcpy(provider, PROVIDER_AUSTRIA_TMOBILE);
			return 0;
		}  	
        	else if((frequency >= 1755400)&&(frequency <= 1756400))
		{
			strcpy(provider, PROVIDER_AUSTRIA_MOBILKOM);
			return 0;
		}  	 	 	  	 	
        	else if((frequency >= 1756800)&&(frequency <= 1757800))
		{
			strcpy(provider, PROVIDER_AUSTRIA_TMOBILE);
			return 0;
		}
        	else if((frequency >= 1758200)&&(frequency <= 1781400))
		{
			strcpy(provider, PROVIDER_AUSTRIA_ONE);
			return 0;
		}      		
        	else if((frequency >= 1805200)&&(frequency <= 1807000))
		{
			strcpy(provider, PROVIDER_AUSTRIA_TMOBILE);
			return 0;
		}  
        	else if((frequency >= 1807400)&&(frequency <= 1817400))
		{
			strcpy(provider, PROVIDER_AUSTRIA_MOBILKOM);
			return 0;
		}      		    		
         	else if((frequency >= 1817800)&&(frequency <= 1826200))
		{
			strcpy(provider, PROVIDER_AUSTRIA_TMOBILE);
			return 0;
		}  	
         	else if((frequency >= 1826600)&&(frequency <= 1828800))
		{
			strcpy(provider, PROVIDER_AUSTRIA_MOBILKOM);
			return 0;
		}  	
         	else if((frequency >= 1829200)&&(frequency <= 1834600))
		{
			strcpy(provider, PROVIDER_AUSTRIA_ONE);
			return 0;
		}  	
         	else if((frequency >= 1835000)&&(frequency <= 1836000))
		{
			strcpy(provider, PROVIDER_AUSTRIA_TMOBILE);
			return 0;
		}  	
          	else if((frequency >= 1836400)&&(frequency <= 1837400))
		{
			strcpy(provider, PROVIDER_AUSTRIA_MOBILKOM);
			return 0;
		}  	
           	else if((frequency >= 1837800)&&(frequency <= 1838800))
		{
			strcpy(provider, PROVIDER_AUSTRIA_TMOBILE);
			return 0;
		}  	
           	else if((frequency >= 1839200)&&(frequency <= 1842600))
		{
			strcpy(provider, PROVIDER_AUSTRIA_TMOBILE);
			return 0;
		}  	
           	else if((frequency >= 1843000)&&(frequency <= 1845200))
		{
			strcpy(provider, PROVIDER_AUSTRIA_TMOBILE);
			return 0;
		}  	  	
           	else if((frequency >= 1845600)&&(frequency <= 1850000))
		{
			strcpy(provider, PROVIDER_AUSTRIA_TMOBILE);
			return 0;
		} 
           	else if((frequency >= 1850400)&&(frequency <= 1851400))
		{
			strcpy(provider, PROVIDER_AUSTRIA_MOBILKOM);
			return 0;
		} 
             	else if((frequency >= 1851800)&&(frequency <= 1852800))
		{
			strcpy(provider, PROVIDER_AUSTRIA_TMOBILE);
			return 0;
		} 
             	else if((frequency >= 1853200)&&(frequency <= 1876400))
		{
			strcpy(provider, PROVIDER_AUSTRIA_ONE);
			return 0;
		} 
	}
	else if(country == COUNTRY_SWISS)
	{	
		/* GSM900 */
		if((frequency >= 880100)&&(frequency <= 883300))
		{
			strcpy(provider, PROVIDER_SWISS_ORANGE);
			return 0;
		}
             	else if((frequency >= 883500)&&(frequency <= 889900))
		{
			strcpy(provider, PROVIDER_SWISS_SUNRISE);
			return 0;
		} 
             	else if((frequency >= 890100)&&(frequency <= 902300))
		{
			strcpy(provider, PROVIDER_SWISS_SWISSCOM);
			return 0;
		} 
             	else if((frequency >= 902500)&&(frequency <= 907300))
		{
			strcpy(provider, PROVIDER_SWISS_SUNRISE);
			return 0;
		} 
               	else if((frequency >= 907500)&&(frequency <= 908900))
		{
			strcpy(provider, PROVIDER_SWISS_SWISSCOM);
			return 0;
		} 	  	
               	else if((frequency >= 909100)&&(frequency <= 914900))
		{
			strcpy(provider, PROVIDER_SWISS_SUNRISE);
			return 0;
		} 
               	else if((frequency >= 925100)&&(frequency <= 928300))
		{
			strcpy(provider, PROVIDER_SWISS_ORANGE);
			return 0;
		} 
               	else if((frequency >= 928500)&&(frequency <= 934900))
		{
			strcpy(provider, PROVIDER_SWISS_SUNRISE);
			return 0;
		} 
               	else if((frequency >= 935100)&&(frequency <= 947300))
		{
			strcpy(provider, PROVIDER_SWISS_SWISSCOM);
			return 0;
		}
               	else if((frequency >= 947500)&&(frequency <= 952300))
		{
			strcpy(provider, PROVIDER_SWISS_SUNRISE);
			return 0;
		} 
                else if((frequency >= 952500)&&(frequency <= 953900))
		{
			strcpy(provider, PROVIDER_SWISS_SWISSCOM);
			return 0;
		} 
                else if((frequency >= 954100)&&(frequency <= 959900))
		{
			strcpy(provider, PROVIDER_SWISS_SUNRISE);
			return 0;
		}
		/* GSM1800 */
  	    	else if((frequency >= 1710100)&&(frequency <= 1736300))
		{
			strcpy(provider, PROVIDER_SWISS_ORANGE);
			return 0;
		}
  	    	else if((frequency >= 1736500)&&(frequency <= 1751700))
		{
			strcpy(provider, PROVIDER_SWISS_SWISSCOM);
			return 0;
		}
  	    	else if((frequency >= 1751900)&&(frequency <= 1760300))
		{
			strcpy(provider, PROVIDER_SWISS_SUNRISE);
			return 0;
		}  
  	    	else if((frequency >= 1760500)&&(frequency <= 1763700))
		{
			strcpy(provider, PROVIDER_SWISS_ORANGE);
			return 0;
		}
  	    	else if((frequency >= 1763900)&&(frequency <= 1766900))
		{
			strcpy(provider, PROVIDER_SWISS_SUNRISE);
			return 0;
		}  		
  	    	else if((frequency >= 1767100)&&(frequency <= 1775700))
		{
			strcpy(provider, PROVIDER_SWISS_TELE2);
			return 0;
		}
  	    	else if((frequency >= 1775900)&&(frequency <= 1781700))
		{
			strcpy(provider, PROVIDER_SWISS_INPHONE);
			return 0;
		}
  	    	else if((frequency >= 1781900)&&(frequency <= 1784100))
		{
			strcpy(provider, PROVIDER_SWISS_SUNRISE);
			return 0;
		}  		
  	    	else if((frequency >= 1805100)&&(frequency <= 1831300))
		{
			strcpy(provider, PROVIDER_SWISS_ORANGE);
			return 0;
		}
  	    	else if((frequency >= 1831500)&&(frequency <= 1846700))
		{
			strcpy(provider, PROVIDER_SWISS_SWISSCOM);
			return 0;
		} 		
  	    	else if((frequency >= 1846900)&&(frequency <= 1855300))
		{
			strcpy(provider, PROVIDER_SWISS_SUNRISE);
			return 0;
		}
  	    	else if((frequency >= 1855500)&&(frequency <= 1858700))
		{
			strcpy(provider, PROVIDER_SWISS_ORANGE);
			return 0;
		}
  	    	else if((frequency >= 1858900)&&(frequency <= 1861900))
		{
			strcpy(provider, PROVIDER_SWISS_SUNRISE);
			return 0;
		}
  	    	else if((frequency >= 1862100)&&(frequency <= 1870700))
		{
			strcpy(provider, PROVIDER_SWISS_TELE2);
			return 0;
		} 
  	    	else if((frequency >= 1870900)&&(frequency <= 1876700))
		{
			strcpy(provider, PROVIDER_SWISS_INPHONE);
			return 0;
		} 
  	    	else if((frequency >= 1876900)&&(frequency <= 1879100))
		{
			strcpy(provider, PROVIDER_SWISS_SUNRISE);
			return 0;
		} 
	}
	else if(country == COUNTRY_ENGLAND)
	{	
		/* GSM900 */
		if((frequency >= 880100)&&(frequency <= 885100))
		{
			strcpy(provider, PROVIDER_ENGLAND_VODAFONE);
			return 0;
		}
		else if((frequency >= 885100)&&(frequency <= 890100))
		{
			strcpy(provider, PROVIDER_ENGLAND_O2);
			return 0;
		}
		else if((frequency >= 890100)&&(frequency <= 894700))
		{
			strcpy(provider, PROVIDER_ENGLAND_VODAFONE);
			return 0;
		}
  		else if((frequency >= 894700)&&(frequency <= 902100))
		{
			strcpy(provider, PROVIDER_ENGLAND_O2);
			return 0;
		}
		else if((frequency >= 902100)&&(frequency <= 909900))
		{
			strcpy(provider, PROVIDER_ENGLAND_VODAFONE);
			return 0;
		}
  		else if((frequency >= 909900)&&(frequency <= 914900))
		{
			strcpy(provider, PROVIDER_ENGLAND_O2);
			return 0;
		}
		else if((frequency >= 925100)&&(frequency <= 930100))
		{
			strcpy(provider, PROVIDER_ENGLAND_VODAFONE);
			return 0;
		}
  		else if((frequency >= 930100)&&(frequency <= 935100))
		{
			strcpy(provider, PROVIDER_ENGLAND_O2);
			return 0;
		}  	
		else if((frequency >= 935100)&&(frequency <= 939700))
		{
			strcpy(provider, PROVIDER_ENGLAND_VODAFONE);
			return 0;
		}
  		else if((frequency >= 939700)&&(frequency <= 947100))
		{
			strcpy(provider, PROVIDER_ENGLAND_O2);
			return 0;
		}   	  	
		else if((frequency >= 947100)&&(frequency <= 954900))
		{
			strcpy(provider, PROVIDER_ENGLAND_VODAFONE);
			return 0;
		}
  		else if((frequency >= 954900)&&(frequency <= 959900))
		{
			strcpy(provider, PROVIDER_ENGLAND_O2);
			return 0;
		}
		/* GSM1800 */
  	    	else if((frequency >= 1710100)&&(frequency <= 1715900))
		{
			strcpy(provider, PROVIDER_ENGLAND_O2);
			return 0;
		}
  	    	else if((frequency >= 1715900)&&(frequency <= 1721700))
		{
			strcpy(provider, PROVIDER_ENGLAND_VODAFONE);
			return 0;
		}
  	    	else if((frequency >= 1721700)&&(frequency <= 1751700))
		{
			strcpy(provider, PROVIDER_ENGLAND_TMOBILE);
			return 0;
		}
  	    	else if((frequency >= 1751700)&&(frequency <= 1781700))
		{
			strcpy(provider, PROVIDER_ENGLAND_ORANGE);
			return 0;
		}
  	    	else if((frequency >= 1805100)&&(frequency <= 1810900))
		{
			strcpy(provider, PROVIDER_ENGLAND_O2);
			return 0;
		}
  	    	else if((frequency >= 1810900)&&(frequency <= 1816700))
		{
			strcpy(provider, PROVIDER_ENGLAND_VODAFONE);
			return 0;
		}
  	    	else if((frequency >= 1816700)&&(frequency <= 1846700))
		{
			strcpy(provider, PROVIDER_ENGLAND_TMOBILE);
			return 0;
		}
  	    	else if((frequency >= 1846700)&&(frequency <= 1876700))
		{
			strcpy(provider, PROVIDER_ENGLAND_ORANGE);
			return 0;
		}
	}

	return -1;
}
/* #################################################################################### */


/* ## REVERSE LOOKUP TABLES ########################################################### */



#if 0

/* Find the offset for a given uplink frequency */
int fuplink2offset(int frequency)
{
	if((frequency >= 450600)&&(frequency <= 457400))	/* GSM 450 */
		return 259;
	else if((frequency >= 479000)&&(frequency <= 485800))	/* GSM 480 */
		return 306;
	else if((frequency >= 824200)&&(frequency <= 848800))	/* GSM 850 */
		return 128;
	else if((frequency >= 890000)&&(frequency <= 914800))	/* E-GSM, R-GSM or P-GSM */
		return 0;
	else if((frequency >= 876200)&&(frequency <= 889800)) 	/* R-GSM or E-GSM */
		return 1024;
	else if((frequency >= 1850200)&&(frequency <= 1909800))	/* PCS 1900 (GSM 1900) */
		return 512;
	else if((frequency >= 1710200)&&(frequency <= 1784800))	/* DCS 1800 (GSM 1800) */
		return ARFCN_GSM1800_START;
	else
		return -1;
}

/* Find the offset for a given downlink frequency */
int fdownlink2offset(int frequency)
{
	if((frequency >= 460600)&&(frequency <= 467400))	/* GSM 450 */
		return 259;
	else if((frequency >= 489000)&&(frequency <= 495800))	/* GSM 480 */
		return 306;
	else if((frequency >= 896200)&&(frequency <= 893800))	/* GSM 850 */
		return 128;
	else if((frequency >= 935000)&&(frequency <= 959800))	/* E-GSM, R-GSM or P-GSM */
		return 0;
	else if((frequency >= 921200)&&(frequency <= 934800))	/* R-GSM or E-GSM */
		return 1024;
	else if((frequency >= 1930200)&&(frequency <= 1989800))	/* PCS 1900 (GSM 1900) */
		return 512;
	else if((frequency >= 1805200)&&(frequency <= 1879800))	/* DCS 1800 (GSM 1800) */
		return ARFCN_GSM1800_START;
	else
		return -1;
}

/* Find the startfrequency for a given uplink frequency */
int fuplink2startfreq(int frequency)
{
	if((frequency >= 450600)&&(frequency <= 457400))	/* GSM 450 */
		return 450600;
	else if((frequency >= 479000)&&(frequency <= 485800))	/* GSM 480 */
		return 479000;
	else if((frequency >= 824200)&&(frequency <= 848800))	/* GSM 850 */
		return 824200;
	else if((frequency >= 890000)&&(frequency <= 914800))	/* E-GSM, R-GSM or P-GSM */
		return 890000;
	else if((frequency >= 876200)&&(frequency <= 889800))	/* R-GSM or E-GSM */
		return 890000;
	else if((frequency >= 1850200)&&(frequency <= 1909800))	/* PCS 1900 (GSM 1900) */
		return 1850200;
	else if((frequency >= 1710200)&&(frequency <= 1784800))	/* DCS 1800 (GSM 1800) */
		return 1710200;
	else
		return -1;
}

/* Find the startfrequency for a given downlink frequency */
int fdownlink2startfreq(int frequency)
{
	if((frequency >= 460600)&&(frequency <= 467400))	/* GSM 450 */
		return 450600;
	else if((frequency >= 489000)&&(frequency <= 495800))	/* GSM 480 */
		return 479000;
	else if((frequency >= 896200)&&(frequency <= 893800))	/* GSM 850 */
		return 824200;
	else if((frequency >= 935000)&&(frequency <= 959800))	/* E-GSM, R-GSM or P-GSM */
		return 890000;
	else if((frequency >= 921200)&&(frequency <= 934800))	/* R-GSM or E-GSM */
		return 890000;
	else if((frequency >= 1930200)&&(frequency <= 1989800))	/* PCS 1900 (GSM 1900) */
		return 1850200;
	else if((frequency >= 1805200)&&(frequency <= 1879800))	/* DCS 1800 (GSM 1800) */
		return 1710200;
	else
		return -1;
}

/* Find the difference between rx and tx for a given uplink frequency */
int fuplink2rxtxdiff(int frequency)
{
	if((frequency >= 450600)&&(frequency <= 457400))	/* GSM 450 */
		return 10000;
	else if((frequency >= 479000)&&(frequency <= 485800))	/* GSM 480 */
		return 10000;
	else if((frequency >= 824200)&&(frequency <= 848800))	/* GSM 850 */
		return 45000;
	else if((frequency >= 890000)&&(frequency <= 914800))	/* E-GSM, R-GSM or P-GSM */
		return 45000;
	else if((frequency >= 876200)&&(frequency <= 889800))	/* R-GSM or E-GSM */
		return 45000;
	else if((frequency >= 1850200)&&(frequency <= 1909800))	/* PCS 1900 (GSM 1900) */
		return 80000;
	else if((frequency >= 1710200)&&(frequency <= 1784800))	/* DCS 1800 (GSM 1800) */
		return 95000;
	else
		return -1;
}

/* Find the difference between rx and tx for a given downlink frequency */
int fdownlink2rxtxdiff(int frequency)
{
	if((frequency >= 460600)&&(frequency <= 467400))	/* GSM 450 */
		return 10000;
	else if((frequency >= 489000)&&(frequency <= 495800))	/* GSM 480 */
		return 10000;
	else if((frequency >= 896200)&&(frequency <= 893800))	/* GSM 850 */
		return 45000;
	else if((frequency >= 935000)&&(frequency <= 959800))	/* E-GSM, R-GSM or P-GSM */
		return 45000;
	else if((frequency >= 921200)&&(frequency <= 934800))	/* R-GSM or E-GSM */
		return 45000;
	else if((frequency >= 1930200)&&(frequency <= 1989800))	/* PCS 1900 (GSM 1900) */
		return 80000;
	else if((frequency >= 1805200)&&(frequency <= 1879800))	/* DCS 1800 (GSM 1800) */
		return 95000;
	else
		return -1;
}
#endif

/* #################################################################################### */

