/*
   ####################################################################################
   #                                                                                  #
   #             Arfcncalc - GSM Arfcn frequency calculation tool V1.0.0              #
   #                                 Provider names                                   #
   #                                                                                  #
   #    Copyright (C) 2008 Philipp Fabian Benedikt Maier (aka. Dexter)                #
   #                                                                                  #
   #    This program is free software; you can redistribute it and/or modify          #
   #    it under the terms of the GNU General Public License as published by          #
   #    the Free Software Foundation; either version 2 of the License, or             #
   #    (at your option) any later version.                                           #
   #                                                                                  #
   #    This program is distributed in the hope that it will be useful,               #
   #    but WITHOUT ANY WARRANTY; without even the implied warranty of                #
   #    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the                 #
   #    GNU General Public License for more details.                                  #
   #                                                                                  #
   #    You should have received a copy of the GNU General Public License             #
   #    along with this program; if not, write to the Free Software                   #
   #    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA    #
   #                                                                                  #
   #################################################################################### */


/* ## HEADER ########################################################################## */
#ifndef PROVIDER_H
#define PROVIDER_H

#define PROVIDER_GERMANY_TMOBILE "T-Mobile (262 01)"
#define PROVIDER_GERMANY_VODAFONE "Vodafone (262 02)"
#define PROVIDER_GERMANY_EPLUS "E-Plus (262 03)"
#define PROVIDER_GERMANY_O2 "o2 (262 07)"
#define PROVIDER_GERMANY_DEUTSCHEBAHN "DB-Telematik (262 10)"

#define PROVIDER_AUSTRIA_ONE "One (232 05)"
#define PROVIDER_AUSTRIA_MOBILKOM "Mobilkom (232 01)"
#define PROVIDER_AUSTRIA_TMOBILE "T-Mobile Aaustria (232 03)"

#define PROVIDER_SWISS_ORANGE "Orange (228 03)"
#define PROVIDER_SWISS_SUNRISE "Sunrise (228 02)"
#define PROVIDER_SWISS_SWISSCOM "Swisscom (228 01)"
#define PROVIDER_SWISS_TELE2 "Tele2 (228 08)"
#define PROVIDER_SWISS_INPHONE "Inphone (228 07)"

#define PROVIDER_ENGLAND_VODAFONE "Vodafone (234 91)"
#define PROVIDER_ENGLAND_O2 "o2 (234 10)"
#define PROVIDER_ENGLAND_TMOBILE "T-Mobile UK (234 32)"
#define PROVIDER_ENGLAND_ORANGE "Orange (234 33/34)"





#endif /*PROVIDER_H*/
/* #################################################################################### */
